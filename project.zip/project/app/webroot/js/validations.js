		// validate signup form on keyup and submit
$(document).ready(function() {
	 $.validator.addMethod( 
		        'email',
		        function(value, element){
		            return this.optional(element) || /(^[-!#$%&'*+/=?^_`{}|~0-9A-Z]+(\.[-!#$%&'*+/=?^_`{}|~0-9A-Z]+)*|^"([\001-\010\013\014\016-\037!#-\[\]-\177]|\\[\001-\011\013\014\016-\177])*")@((?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)$)|\[(25[0-5]|2[0-4]\d|[0-1]?\d?\d)(\.(25[0-5]|2[0-4]\d|[0-1]?\d?\d)){3}\]$/i.test(value);
		        }        
		    );
$.validator.addMethod('passw', function (value) { 
    return /^$|^(?=.*\d)(?=.*[a-z])(?=.*\W.*)(?=.*[A-Z]).{8,12}$/.test(value); 
}, '<br>Password must be at least 8 characters, no more than 12 characters, and must include at least one upper case letter, one lower case letter, and one numeric digit.<br>');

$.validator.addMethod('passw_withoutspace', function (value) { 
    return /^$|^(?=.*\d)(?=.*[a-z])(?=.*\W.*)(?=.*[A-Z]).{8,12}$/.test(value); 
}, '<br>Password must be at least 8 characters, no more than 12 characters, and must include at least one upper case letter, one lower case letter, and one numeric digit.<br>');

$("#user_regis").validate({
			rules: {
				'data[User][first_name]': {
					required: true,
				},
				'data[User][last_name]': {
					required: true,
				},
				'data[User][email]': {
					required: true,
					email:true,
					remote:WEB_ROOT+'Validations/validate_user_regis/email',
				},
				'data[User][password]': {
					required: true,
					passw_withoutspace: true,
				},
				'data[User][department]': {
					required: true,
				},
	
			},
			messages: {
				'data[User][first_name]': {
					required: 'please provide first name<br>',
				},
				'data[User][last_name]': {
					required: 'please provide last name<br>',
				},
				'data[User][email]': {
					required: 'please provide email address<br>',
					email:'please provide valid email address<br>',
					remote:'Email already registered<br>'
				},
				'data[User][password]': {
					required: 'please provide password<br>',
					minlength: 'Please enter at least 3 characters.<br>',
					maxlength: 'Please enter no more than 12 characters.<br>',
					
				},
				'data[User][department]': {
					required: 'please provide department name<br>',
				},
			}
		});


$("#user_edit").validate({
	rules: {
		'data[User][first_name]': {
			required: true,
		},
		'data[User][last_name]': {
			required: true,
		},
		'data[User][email]': {
			required: true,
			email:true,
			remote:WEB_ROOT+'Validations/validate_user_regis/email',
		},
		'data[User][password]': {
			passw: true,
		},
		'data[User][department]': {
			required: true,
		},

	},
	messages: {
		'data[User][first_name]': {
			required: 'please provide first name<br>',
		},
		'data[User][last_name]': {
			required: 'please provide last name<br>',
		},
		'data[User][email]': {
			required: 'please provide email address<br>',
			email:'please provide valid email address<br>',
			remote:'Email already registered<br>'
		},
		'data[User][password]': {
			
		},
		'data[User][department]': {
			required: 'please provide department name<br>',
		},
	}
});


$("#UserHomeForm").validate({
	rules: {
		'data[User][email]': {
			required: true,
		},
		'data[User][password]': {
			required: true,
		},

	},
	messages: {
		'data[User][email]': {
			required: 'please provide email address',
		},
		'data[User][password]': {
			required: '<br>please provide password',
		},
		
	}
});




});
		
		
		
		/*
		
		$("#signup_box").validate({
			rules: {
				firstname: "required",
				lastname: "required",
				username: {
					required: true,
					minlength: 2
				},
				password: {
					required: true,
					minlength: 5
				},
				confirm_password: {
					required: true,
					minlength: 5,
					equalTo: "#password"
				},
				email: {
					required: true,
					email: true
				},
				topic: {
					required: "#newsletter:checked",
					minlength: 2
				},
				agree: "required"
			},
			messages: {
				firstname: "Please enter your firstname",
				lastname: "Please enter your lastname",
				username: {
					required: "Please enter a username",
					minlength: "Your username must consist of at least 2 characters"
				},
				password: {
					required: "Please provide a password",
					minlength: "Your password must be at least 5 characters long"
				},
				confirm_password: {
					required: "Please provide a password",
					minlength: "Your password must be at least 5 characters long",
					equalTo: "Please enter the same password as above"
				},
				email: "Please enter a valid email address",
				agree: "Please accept our policy"
			}
		});
		
		*/