$(function() {
  $( "#video_lnk1" ).click(function() {
                           //$( "#search_opt1" ).hide();
                           //$( "#search_opt3" ).hide();
                           //$( "#search_opt2" ).show();
						  $( "#image_search" ).hide();
					      $( "#media_search" ).hide();
					      $( "#video_search" ).show();
      
	  					   $( "#video_lnk1" ).css("font-weight","Bold");
                           $( "#img_lnk1" ).css("font-weight","Normal");
                           $( "#media_lnk1" ).css("font-weight","Normal");
                           setCookie("media_type",'video', 365);
                           });
  });

$(function() {
  $( "#media_lnk1" ).click(function() {
                           //$( "#search_opt1" ).hide();
                           //$( "#search_opt2" ).hide();
                           //$( "#search_opt3" ).show();
						  $( "#image_search" ).hide();
					      $( "#media_search" ).show();
					      $( "#video_search" ).hide();
	  					   $( "#video_lnk1" ).css("font-weight","Normal");
                           $( "#img_lnk1" ).css("font-weight","Normal");
                           $( "#media_lnk1" ).css("font-weight","Bold");
                           setCookie("media_type",'media', 365);
                           });
  });

$(function() {
  $( "#img_lnk1" ).click(function() {
                         //$( "#search_opt3" ).hide();
                         //$( "#search_opt2" ).hide();
                         //$( "#search_opt1" ).show();
						  $( "#image_search" ).show();
					      $( "#media_search" ).hide();
					      $( "#video_search" ).hide();
	  					 $( "#video_lnk1" ).css("font-weight","Normal");
                         $( "#img_lnk1" ).css("font-weight","Bold");
                         $( "#media_lnk1" ).css("font-weight","Normal");
                         setCookie("media_type",'img', 365);
                         });
  });

$(function() {
  $( "#sign_lnk" ).click(function() {
                         $( "#signup_box" ).show();
                         $( "#login_box" ).hide();
                         });
  });

$(function() {
  $( "#close_signup_box" ).click(function() {
                                 $( "#signup_box" ).hide();
                                 });
  });

$(function() {
  $( "#log_lnk" ).click(function() {
                        $( "#login_box" ).show();
                        $( "#signup_box" ).hide();
                        });
  });

$(function() {
  $( "#close_login_box" ).click(function() {
                                $( "#login_box" ).hide();
                                });
  });