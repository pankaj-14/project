$(function() {
  $( "#video_lnk" ).click(function() {
                          //$( "#search_opt1" ).hide();
                          //$( "#search_opt3" ).hide();
                          //$( "#search_opt2" ).show();
                          $( "#image_search" ).hide();
                          $( "#media_search" ).hide();
                          $( "#video_search" ).show();
                          
                          $( "#video_lnk" ).css("font-weight","Bold");
                          $( "#img_lnk" ).css("font-weight","Normal");
                          $( "#media_lnk" ).css("font-weight","Normal");
                          $( "#video_cat_container" ).show();
                          $( "#media_cat_container" ).hide();
                          $( "#img_cat_container" ).hide();
                          $( "#video_tag_box" ).show();
                          $( "#media_tag_box" ).hide();
                          $( "#img_tag_box" ).hide();
                          document.getElementById("hero").style.backgroundImage = "url(/images/top/top_vid_back.jpg)";
                          document.getElementById("hero").style.backgroundRepeat = "no-repeat";
                          document.getElementById("hero").style.backgroundPosition = "center center";
                          setCookie("media_type",'video', 365);                        
  });
  });

$(function() {
  $( "#media_lnk" ).click(function() {
                          //$( "#search_opt1" ).hide();
                          //$( "#search_opt2" ).hide();
                          //$( "#search_opt3" ).show();
						  $( "#image_search" ).hide();
					      $( "#media_search" ).show();
					      $( "#video_search" ).hide();
					      $( "#video_lnk" ).css("font-weight","Normal");
                          $( "#img_lnk" ).css("font-weight","Normal");
                          $( "#media_lnk" ).css("font-weight","Bold");
                          $( "#media_cat_container" ).show();
                          $( "#video_cat_container" ).hide();
                          $( "#img_cat_container" ).hide();
                          $( "#media_tag_box" ).show();
                          $( "#video_tag_box" ).hide();
                          $( "#img_tag_box" ).hide();
                          
                          document.getElementById("hero").style.backgroundImage = "url(/images/top/top_med_back.jpg)";
                          document.getElementById("hero").style.backgroundRepeat = "no-repeat";
                          document.getElementById("hero").style.backgroundPosition = "center center";
                          setCookie("media_type",'media', 365);
  });
  });

$(function() {
  $( "#img_lnk" ).click(function() {
					  $( "#image_search" ).show();
				      $( "#media_search" ).hide();
				      $( "#video_search" ).hide();
				      
                        //$( "#search_opt3" ).hide();
                        //$( "#search_opt2" ).hide();
                        //$( "#search_opt1" ).show();
                        $( "#video_lnk" ).css("font-weight","Normal");
                        $( "#img_lnk" ).css("font-weight","Bold");
                        $( "#media_lnk" ).css("font-weight","Normal");
                        $( "#media_cat_container" ).hide();
                        $( "#video_cat_container" ).hide();
                        $( "#img_cat_container" ).show();
                        $( "#media_tag_box" ).hide();
                        $( "#video_tag_box" ).hide();
                        $( "#img_tag_box" ).show();
                        document.getElementById("hero").style.backgroundImage = "url(/images/top/top_img_back.jpg)";
                        document.getElementById("hero").style.backgroundRepeat = "no-repeat";
                        document.getElementById("hero").style.backgroundPosition = "center center";
                        setCookie("media_type",'img', 365);
                        });
  });

$(function() {
  $( "#sign_lnk" ).click(function() {
                         $( "#signup_box" ).show();
                         $( "#login_box" ).hide();
                         });
  });

$(function() {
  $( "#close_signup_box" ).click(function() {
                                 $( "#signup_box" ).hide();
                                 });
  });

$(function() {
  $( "#log_lnk" ).click(function() {
                        $( "#login_box" ).show();
                        $( "#signup_box" ).hide();
                        });
  });

$(function() {
  $( "#close_login_box" ).click(function() {
                                $( "#login_box" ).hide();
                                });
  });