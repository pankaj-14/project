<?php
App::uses('AppController', 'Controller');
App::uses('CakeEmail', 'Network/Email');
/**
 * Users Controller
 *
 * @property User $User
 * @property PaginatorComponent $Paginator
 */
class UsersController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator','Security', 'Security' => array(
        'csrfUseOnce' => false
    ));

	
	public function beforeFilter() {
		parent::beforeFilter();
		$this->Security->unlockedActions = array('add','index','delete','registration','change_password','reset_password');
		$this->Auth->allow(array(
				'add',
				'signup',
				'forgot_username_password',
				'login',
				'admin_login',
				'admin_logout',
				'activate_account',
				'admin_forget_password',
				'register',
				'registration',
				'test',
				'testmail',
				'change_password'
		));
	}
	
/**
 * index method
 *
 * @return void
 */
	public function index() {
		$user_type = $this->Session->read ( 'Auth.User.type' );
		if (!in_array ($user_type, array ('SUPER_ADMIN'))) {
			return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
		}
		if($this->request->is('ajax'))
		{
			$this->layout=false;
		}
		else {
			$this->layout='internal';
		}
		$condition = array();
		if (! empty ( $_GET ['search'] )) {
			$condition ['User.email like'] = '%'.Sanitize::paranoid($_GET ['search'], Configure::read('global_paranoid')).'%';
		}
		$this->User->recursive = 0;
		$this->Paginator->settings = array (
				'conditions' => $condition,
				//'limit' => 1
		);
		$this->set('users', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
		$options = array('conditions' => array('User.' . $this->User->primaryKey => $id));
		$this->set('user', $this->User->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		$user_type = $this->Session->read ( 'Auth.User.type' );
		if (!in_array ($user_type, array ('SUPER_ADMIN'))) {
			return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
		}
		if ($this->request->is('post')) {
			$this->User->create();
			$new_user = 0;
			if(isset($this->request->data['User']['id']) && $this->request->data['User']['id']>0)
			{
				if(isset($this->request->data['User']['email']))
				{
					unset($this->request->data['User']['email']);
				}
				$info = $this->User->findById($this->request->data['User']['id']);
				if($info['User']['status']!='ACTIVE' && $this->request->data['User']['status']=='ACTIVE')
				{
					$viewVars = array(
							'user_name'=>$this->request->data['User']['first_name'],
					);
					$this->sendMail(array($info['User']['email']), 'activate', $subject='Account Activation', $viewVars );
						
				}
			}
			else 
			{
				$new_user = 1;
				$pass =  $this->generateRandomString(6);
				$this->request->data['User']['password'] = $pass;
			}
			$this->request->data['User']['first_name'] =  Sanitize::html($this->request->data['User']['first_name'], array('remove' => TRUE));
			$this->request->data['User']['last_name'] =  Sanitize::html($this->request->data['User']['last_name'], array('remove' => TRUE));
			$this->request->data['User']['department'] =  Sanitize::html($this->request->data['User']['department'], array('remove' => TRUE));
				
			
			if ($this->User->save($this->request->data)) {
				if($new_user==1)
				{
					$viewVars = array(
							'user_name'=>$this->request->data['User']['first_name'],
							'pass'=>$pass
					);
					$this->sendMail(array($this->request->data['User']['email']), 'add_user_by_admin', $subject='Welcome to digital library', $viewVars );
					
				}
				//$this->Session->setFlash(__('The user has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				//$this->Session->setFlash(__('The user could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if ($id!=$this->Session->read ( 'Auth.User.id' )) {
			return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
		}
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
		if ($this->request->is(array('post', 'put'))) {

				if(empty($this->request->data['User']['first_name']) || empty($this->request->data['User']['last_name']) || empty($this->request->data['User']['department']))
				{
					$message = 'Please enter proper user information and try again.';
					$this->Session->setFlash(__($message),'default', array ('class' => 'errormsg'));
					return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
				}
				$this->request->data['User']['first_name'] =  Sanitize::html($this->request->data['User']['first_name'], array('remove' => TRUE));
				$this->request->data['User']['last_name'] =  Sanitize::html($this->request->data['User']['last_name'], array('remove' => TRUE));
				$this->request->data['User']['department'] =  Sanitize::html($this->request->data['User']['department'], array('remove' => TRUE));
				
				if(empty(trim($this->request->data['User']['password'])))
				{
					unset($this->request->data['User']['password']);
				}
				else {
					if (!preg_match("/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,12}$/",$this->request->data['User']['password'])) {
					
						$message = 'Please enter proper user information and try again.';
						$this->Session->setFlash(__($message),'default', array ('class' => 'errormsg'));
						return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
					}
				}
				if(isset($this->request->data['User']['type']))
				{
					unset($this->request->data['User']['type']);
				}
				if(isset($this->request->data['User']['email']))
				{
					unset($this->request->data['User']['email']);
				} 
				
				if ($this->User->save($this->request->data)) {
				$this->Session->write('Auth.User.first_name',$this->request->data['User']['first_name']);
				$this->Session->write('Auth.User.last_name',$this->request->data['User']['first_name']);
				$this->Session->write('Auth.User.department_name',$this->request->data['User']['department']);
				$this->Session->setFlash(__('The user has been saved.'));
				if(!empty(trim($this->request->data['User']['password'])))
				{
				$user = $this->User->findById($id);
				if(!empty($user))
				{
						$this->Common->add_activity('Change Pasword','change password by user '.$this->Session->read('Auth.User.first_name')); 
						$password = $this->request->data['User']['password'];
						$viewVars = array('password'=>$password);
						$this->sendMail(array($user['User']['email']), 'change_password', $subject='Password reset notification', $viewVars );
				}
				}
				$this->Common->add_activity('Change Info','update profile by user '.$this->Session->read('Auth.User.first_name')); 
				return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
			} else {
				$this->Session->setFlash(__('The user could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('User.' . $this->User->primaryKey => $id));
			$this->request->data = $this->User->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 *
 *
 *public function delete($id = null) {
		$this->User->id = $id;
		if (!$this->User->exists()) {
			throw new NotFoundException(__('Invalid user'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->User->delete()) {
			$this->Session->setFlash(__('The user has been deleted.'));
		} else {
			$this->Session->setFlash(__('The user could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
 */
	
	public function delete($id = null) {
		$this->User->id = $id;
		if (!$this->User->exists()) {
			throw new NotFoundException(__('Invalid user'));
		}
		if ($this->request->is('post')) {
			$this->User->saveField("status","DELETED");
			$this->Session->setFlash(__('The user has been deleted.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
	
	
	public function registration() {
		if ($this->request->is('post')) {
			if(empty($this->request->data['User']['first_name']) || empty($this->request->data['User']['last_name']) || empty($this->request->data['User']['department']))
			{
				$message = 'Please enter proper user information and try again.';
				$this->Session->setFlash(__($message),'default', array ('class' => 'errormsg'));
				return $this->redirect($this->referer());
			}
			
			if (!preg_match("/^(?=.*\d)(?=.*[a-z])(?=.*\W.*)(?=.*[A-Z]).{8,12}$/",$this->request->data['User']['password'])) {
					$message = 'pass Please enter proper user information and try again.';
					$this->Session->setFlash(__($message),'default', array ('class' => 'errormsg'));
					return $this->redirect($this->referer());
				}
			
			$this->User->set($this->request->data);
			if (!$this->User->validates()) {
				$errors = $this->User->validationErrors;
				$message = 'The user could not be saved. Please, try again.';
				$this->Session->setFlash(__($message),'default', array ('class' => 'errormsg'));
				return $this->redirect($this->referer());
			}
			$this->User->create();
			$this->request->data['User']['type'] = 'SUPER_ADMIN';
			$this->request->data['User']['is_active'] = '0';
			$this->request->data['User']['status'] = 'ACTIVE';
			$email = $this->request->data['User']['email'];
			$email_type = explode('@',$email)[1];
			$email_registered = array('cairnindia.com','gmail.com','aumlsolutions.com');
			
			if(!in_array($email_type, $email_registered))
			{
				$message = "Your @$email_type is not authorised. Please Contact Administrator.";
				$this->Session->setFlash(__($message),'default', array ('class' => 'errormsg'));
				//return $this->redirect($this->referer());
				return $this->redirect('/');
			}
			$this->request->data['User']['first_name'] =  Sanitize::html($this->request->data['User']['first_name'], array('remove' => TRUE));
			$this->request->data['User']['last_name'] =  Sanitize::html($this->request->data['User']['last_name'], array('remove' => TRUE));
			$this->request->data['User']['department'] =  Sanitize::html($this->request->data['User']['department'], array('remove' => TRUE));
				
			if ($this->User->save($this->request->data)) {
				$this->Session->setFlash(__('The user has been saved.'),'default', array ('class' => 'successmsg'));
				
				$viewVars = array(
						'user_name'=>$this->request->data['User']['first_name'],
				);
				$this->sendMail(array($email), 'register', $subject='Welcome to digital library', $viewVars );
				
				return $this->redirect('/');
				//return $this->redirect($this->referer());
			} else {
				$message = 'The user could not be saved. Please, try again.';
				$errors = $this->User->invalidFields();
				if(!empty($errors['email'][0]))
						{
							$message = $errors['email'][0];
							
						}
				$this->Session->setFlash(__($message),'default', array ('class' => 'errormsg'));
				return $this->redirect($this->referer());
			}
		}
	}
	
	
	function testmail(){
		Configure::write('debug', 1);
		$viewVars = array('name'=>'pankaj');
		$this->set('pankajkhali14@mail.com');
		$s = $this->sendMail(array('test2@aumlsolutions.com'), 'welcome', $subject='Crain India', $viewVars );
		print_r($s);
		die('Failed');
	}
	
	
	public function login() {
		if ($this->Session->read('Auth.User')){ 
			return $this->redirect("/");
		}
	
		if ($this->request->is('post')) {
			if ($this->Auth->login()) {
				
				$active = $this->Auth->user('status');
				$this->Session->write('login_mail','');
				$this->Session->write('count','');
				if($active=='ACTIVE')
				{
					$this->User->id = $this->Session->read('Auth.User.id');
				    $this->User->saveField("last_login",date('Y-m-d H:i:s'));
					$this->Common->add_activity('Last Login','Logged in by '.$this->Session->read('Auth.User.first_name')); 
					return $this->redirect($this->referer());
				}
				else if($active=='ARCHIVED')
				{
					$this->Session->write('Auth.User',array());
					$this->Session->setFlash(__('Your cairn account has been deactivate.'),'default', array ('class' => 'errormsg'));
					return $this->redirect($this->referer());
				}
				else
				{
					$this->Session->write('Auth.User',array());
					$this->Session->setFlash(__('Your cairn account has not been activated yet.'),'default', array ('class' => 'errormsg'));
					return $this->redirect($this->referer());
				}
			}
			else
			{	
				$count = '';
				if(!empty($this->Session->read('login_mail')))
				{
					if($this->Session->read('login_mail') == $this->request->data['User']['email'])
					{
						 $count = $this->Session->read('count')+1 ;
							
						if($count>=5)
						{
							$this->User->updateAll(array("status"=>"'ARCHIVED'"),array("email"=>$this->request->data['User']['email']));
						}
					}
					else 
					{	
						$this->Session->write('login_mail',$this->request->data['User']['email']);
						$count = 1;
							
					}
					$this->Session->write('count',$count);
				}
				else 
				{   
					$this->Session->write('login_mail',$this->request->data['User']['email']);
					$this->Session->write('count',1);
						
				}
				$this->Session->setFlash(__('Invalid username or password, try again'),'default', array ('class' => 'errormsg'));
				return $this->redirect($this->referer());
			}
			
			
		}
		return $this->redirect($this->referer());
	}
	
	
	public function logout()
	{
		$this->Auth->logout(); 
		return $this->redirect('/');
	}
	
	
	public function dashboard()
	{
		$this->layout='internal';
		$pending = $this->User->find('count', array(
				'conditions' => array('User.status' => 'NEW')
		));
		$this->set('pending_user',$pending);
		$user_data = $this->User->findById($this->Session->read('Auth.User.id'));
		$this->set('user_data',$user_data); 
	}
	
	
	public function change_password()
	{
		$this->layout=false;
		$this->autoRender=false;
		$message = 'Please ensure that your email is correct!!';
		if ($this->request->is('post')) {
			$email = Sanitize::paranoid($_POST['email'], Configure::read('global_paranoid'));
			$user = $this->User->findByEmail($email);
			if(!empty($user))
			{
				$password = $this->generateRandomString(6);
				$user['User']['password']=$password;
				if($this->User->save($user))
				{
					$viewVars = array('password'=>$password);
					$this->sendMail(array($user['User']['email']), 'change_password', $subject='Password reset notification', $viewVars );
					$message = 'Your password has been sent to your email';
				}
				
			}
			return $message;
		}
	}
	
		public function demo()
	{
		$this->layout='internal';
	}

	
	public function reset_password($id)
	{
		$this->layout=false;
		$this->autoRender=false;
		if ($this->request->is('post')) {
			$user = $this->User->findById($id);
			if(!empty($user))
			{
				$password = $this->generateRandomString(6);
				$user['User']['password']=$password;
				if($this->User->save($user))
				{
					$viewVars = array('password'=>$password);
					$viewVars = array(
							'user_name' => $user['User']['first_name'],
							'password'=>$password
					);
					$this->sendMail(array($user['User']['email']), 'reset_password', $subject='Password reset notification', $viewVars );
					$message = 'password has been reset';
				}
	
			}
			return $message;
		}
	}
}
