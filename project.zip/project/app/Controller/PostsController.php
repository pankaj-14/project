<?php
class PostsController extends AppController {
	var $name = 'Posts';

	function import() {
		$messages = $this->Post->import('posts.csv');
		echo "<pre>"; print_r($messages);
		die;
	}

	public function demo()
	{
		
	}
}
?>

