<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');
App::uses('Sanitize', 'Utility');
/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {
	//public $components = array('Auth', 'Session','RequestHandler','Cookie','Paginator');
	//public $helpers = array('Js' => array('Jquery'),'Js','Paginator');
	public $components = array('JqueryFileUpload.Upload','Auth', 'Session','RequestHandler','Cookie','Paginator','Common');
	public $helpers = array('JqueryFileUpload.UploadScript', 'JqueryFileUpload.UploadTemplate','Js' => array('Jquery'),'Js','Paginator');
	
	//public $components = array('Auth', 'Session','RequestHandler','Cookie','Paginator');
	//public $helpers = array('Js' => array('Jquery'),'Js','Paginator');
	
	public function beforeFilter() {
		$this->Paginator->settings = array(
				'limit' => 20
		);
    	
		$this->Auth->loginRedirect = array('controller' => 'pages', 'action' => 'home');
		$this->Auth->logoutRedirect = array('controller' => 'pages', 'action' => 'home');
		
		$this->Auth->authenticate = array(
					'all' => array (
							//'scope' => array('User.is_active' => 1)
					),
					'Basic'=>array(
							'fields' => array('username' => 'email')
					),
					'Form' => array(
							'fields' => array('username' => 'email')
					)
			);
		
		}
	
	public function beforeRender() {

		foreach ($_GET as $key=>$val)
		{
			$_GET [$key] = Sanitize::paranoid($_GET [$key], Configure::read('global_paranoid'));
				
		}
	}
	
	
	function generateRandomString($length = 6) {
		return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
	}
	
	
	function sendMail($to, $template, $subject='Client Result', $viewVars = array(), $from='no-reply@support.com', $attachmentFile = array(),$layout='default',$fromName = 'Support'){
		$Email = new CakeEmail();
		$Email->emailFormat('html');
		$Email->config('crain_smtp');
	    //$Email->transport('debug');
		$Email->template($template, $layout);
		$Email->viewVars($viewVars);
		$Email->attachments($attachmentFile);
		$Email->from(array($from => $fromName));
		$Email->to($to);
		$Email->subject($subject);
		if($Email->send()){
			return true;
		}
		return false;
	}
	
	
}
