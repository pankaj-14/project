<?php
App::uses('AppController', 'Controller');
class ValidationsController extends AppController {
    public $uses = array('User');
    public $layout = null;
    public function beforeFilter() {
            parent::beforeFilter();
            $this->Auth->allow(array(    
                        'validate_user_regis'
                    ));
         //    Configure::write('debug', 0);
         }   
          
    public function validate_user($fieldName=null){           
        $this->autoRender = false;
        $value = Sanitize::paranoid($_GET['email'], Configure::read('global_paranoid'));
        $id = Sanitize::paranoid($_GET['id'], Configure::read('global_paranoid'));
        $findBy = 'findBy'.Inflector::camelize($fieldName);       
        if (!empty($id)) {
                $user_data = $this->User->find('count', array(
                    'conditions' => array(
                        "NOT" => array("User.id" => $id),
                        "User.$fieldName" => $value
                )));
        }else{
             $user_data = $this->User->$findBy($value);
        }
        if(empty($user_data)){
            return true;
        }else{
            return false;
        } 
    }
    
     
    public function validate_user_regis($fieldName=null){
    	$this->autoRender = false;
    	$value = Sanitize::paranoid($_GET['data']['User'][$fieldName], Configure::read('global_paranoid'));
        $findBy = 'findBy'.Inflector::camelize($fieldName);
    	$user_data = $this->User->$findBy($value);
    	
     if(empty($user_data)){
            echo 'true';
        }else{
            echo 'false';
        } 
    }
    
    
    
    
}
?>