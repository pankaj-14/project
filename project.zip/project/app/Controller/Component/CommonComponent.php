<?php 
App::uses('Component', 'Controller');
App::uses('Log', 'Model');

class CommonComponent extends Component {
    public $components = array('Session');
    public function add_activity($activity,$comment) {
    			$Log = ClassRegistry::init('Log');
				$Log->Create();
				$data['Log']['user_id'] = $this->Session->read('Auth.User.id');
				$data['Log']['activity_type'] = $activity;
			  	$data['Log']['comment'] = $comment;
			    $Log->save($data);
		  	
    }
}

?>