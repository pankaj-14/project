<?php
App::uses('AppController', 'Controller');
App::uses('CakeEmail', 'Network/Email');
/**
 * Users Controller
 *
 * @property User $User
 * @property PaginatorComponent $Paginator
 */
class ClientsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	//public $components = array('Paginator','Security');
	public $components = array(
    'Security' => array(
        'csrfUseOnce' => false
    )
);
	
	public function beforeFilter() {
		parent::beforeFilter();
		//$this->Security->unlockedActions = array('upload');
		$this->Auth->allow(array(
				
		));
		//$this->Security->unlockedActions = array('upload');
	}
	
/**
 * index method
 *
 * @return void
 */

public function index() {
		$user_type = $this->Session->read ( 'Auth.User.type' );
		if (!in_array ($user_type, array ('SUPER_ADMIN'))) {
			return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
		}
		if($this->request->is('ajax'))
		{
			$this->layout=false;
		}
		else {
			$this->layout='internal';
		}
		$condition = array();
		if (! empty ( $_GET ['search'] )) {
			$condition ['Client.first_name like'] = '%'.Sanitize::paranoid($_GET ['search'], Configure::read('global_paranoid')).'%';
		}
		$this->Client->recursive = 0;
		$this->Paginator->settings = array (
				'conditions' => $condition,
				//'limit' => 1
		);
		$this->set('clients', $this->Paginator->paginate());
	}



	public function upload_data() {
		
		$user_type = $this->Session->read ( 'Auth.User.type' );
		if (!in_array ($user_type, array ('SUPER_ADMIN','ADMIN'))) {
			return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
		}
		$this->layout = 'internal';
	
	}

	public function search_data() {
		
		$user_type = $this->Session->read ( 'Auth.User.type' );
		if (!in_array ($user_type, array ('SUPER_ADMIN','ADMIN'))) {
			return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
		}
		$this->layout = 'internal';
	
	}

	public function upload() {
		$this->autoRender = false;
			$type = $this->request->data['User']['type'];
			$upload_dir = dirname ( $_SERVER ['SCRIPT_FILENAME'] ) .'/'. Configure::read ( 'client_file_path' );
			$upload_url = $this->_get_full_url () . Configure::read ( 'client_file_path' );
			
		    $tmp_dir = dirname ( $_SERVER ['SCRIPT_FILENAME'] ) . Configure::read ( 'temp' );
		    $tmp_url = $this->_get_full_url () . Configure::read ( 'temp' );
			$result = $this->Upload->uploadFile ( array (
				'upload_dir' => $tmp_dir,
				'upload_url' => $tmp_url,
				'mkdir_mode' => 0755,
				'image_versions' => array (
						
						'thumbnail' => array (
								'max_width' => 163,
								'max_height' => 100 
						),
				) 
		), $type=$type,$upload_dir,$upload_url);

	}
	protected function _get_full_url() {
		$https = ! empty ( $_SERVER ['HTTPS'] ) && $_SERVER ['HTTPS'] !== 'off';
		return ($https ? 'https://' : 'http://') . (! empty ( $_SERVER ['REMOTE_USER'] ) ? $_SERVER ['REMOTE_USER'] . '@' : '') . (isset ( $_SERVER ['HTTP_HOST'] ) ? $_SERVER ['HTTP_HOST'] : ($_SERVER ['SERVER_NAME'] . ($https && $_SERVER ['SERVER_PORT'] === 443 || $_SERVER ['SERVER_PORT'] === 80 ? '' : ':' . $_SERVER ['SERVER_PORT']))) . substr ( $_SERVER ['SCRIPT_NAME'], 0, strrpos ( $_SERVER ['SCRIPT_NAME'], '/' ) );
	}


    function import() {
    	$query = $this->Client->query("CALL ".Configure::read('IMPORT_CLIENT'));
    	if($query)
    	{
    	$filename =  dirname ( $_SERVER ['SCRIPT_FILENAME'] ).'/'.Configure::read ('client_file_path'). Configure::read ('client_file_name'); 
		if (file_exists($filename)) {
		    $messages = $this->Client->import(Configure::read('client_file_name'));
		    $this->Common->add_activity('Client data upload','Client Data uploaded by '.$this->Session->read('Auth.User.first_name')); 
		    return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
		} else {
		    //echo "The file $filename does not exist";
		}
		}
		else{
			echo "somthing went wrong"; 
		}

	}

	 function update() {
    	$filename =  dirname ( $_SERVER ['SCRIPT_FILENAME'] ).'/'.Configure::read ('client_file_path'). Configure::read ('update_file_name'); 
		if (file_exists($filename)) {
		    $messages = $this->Client->update(Configure::read('update_file_name'));
		    $this->Common->add_activity('Client data updated','Client Data modified by '.$this->Session->read('Auth.User.first_name')); 
		    return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
		} else {
		    //echo "The file $filename does not exist";
		}
		

	}

	function import_search()
	{
		if ($this->request->is('ajax')) {
		$this->render(false);
		$file = Configure::read ('search_file_name'); 
		$filename =  dirname ( $_SERVER ['SCRIPT_FILENAME'] ).'/'.Configure::read ('client_file_path').$file; 
		if (file_exists($filename)) {
		$this->loadModel('ClientSearch');
		$data = $this->ClientSearch->find('all');
		if(!empty($data))
				{

			    	foreach ($data as $result)
			    	{
			    		$this->loadModel('ClientSearchBackup');
			    		$this->ClientSearchBackup->Create();
			    		$data['ClientSearchBackup']['first_name'] = $result['ClientSearch']['first_name'];
			    		$data['ClientSearchBackup']['last_name'] = $result['ClientSearch']['last_name'];
			    		$data['ClientSearchBackup']['dob'] = $result['ClientSearch']['dob'];
			    		$data['ClientSearchBackup']['country'] = $result['ClientSearch']['country'];
			    		$data['ClientSearchBackup']['search_by'] = $result['ClientSearch']['search_by'];
			    		$data['ClientSearchBackup']['is_found'] = $result['ClientSearch']['is_found'];
			    		
			    		$this->ClientSearchBackup->save($data);
			    	}
			    	$this->ClientSearch->query('TRUNCATE TABLE dls_client_searches');
			   }
		
		$this->ClientSearch->import($file,$this->Session->read('Auth.User.id'));
		$this->Common->add_activity('Client data search','Client Data search by user ('.$this->Session->read('Auth.User.first_name').') using external file'); 
		//$this->search_mail();
		$this->filter_result();
		
		return 1;

		} else {
				    //echo "The file $filename does not exist";
			   }
	}

}




function filter_result()
  {
  	$user_first_name = $this->Session->read ('Auth.User.first_name');
  	$this->render(false);
  	$this->loadModel('ClientSearch');
  	$search_criteria = $this->ClientSearch->find('all');
  	$this->loadModel('Configration');
  	$email_data = $this->Configration->find('first');
  	//$email_to = explode(',',$email_data['Configration']['email_to']);
	$email_to = $email_data['Configration']['email_to'];
	$email_from = $email_data['Configration']['email_from'];
	$email_cc = $email_data['Configration']['email_cc'];
  	$email_bcc = $email_data['Configration']['email_bcc'];
  	if(!empty($search_criteria))
  	{
  		foreach ($search_criteria as $key => $data)
  		{
  			$first_name = $data['ClientSearch']['first_name'];
  			$last_name = $data['ClientSearch']['last_name'];
  			$dob = $data['ClientSearch']['dob'];
  			$country = $data['ClientSearch']['country'];
  		
  			$result = $this->Client->find('first',array('conditions'=>array('first_name'=>$first_name,'last_name'=>$last_name,'city'=>$country,'dob'=>$dob)));
  			if(!empty($result))
  			{
  				$client_id = $result['Client']['id'];
  				$this->ClientSearch->Create();
  				$this->ClientSearch->updateAll(array("is_found"=>"'true'"),array("ClientSearch.id"=>$data['ClientSearch']['id']));
  				$this->loadModel('DeliveredEmail');
  				$this->DeliveredEmail->Create();
  				$email_data['client_id'] = $client_id;
  				$email_data['search_by'] = $data['ClientSearch']['search_by'];
				$email_data['is_searched'] = true;
				$email_data['email_to'] = $email_to;
				$email_data['email_from'] = $email_from;
				$email_data['email_cc'] = $email_cc;
				$email_data['email_bcc'] = $email_bcc;
				
  				$this->DeliveredEmail->save($email_data);
  			}
  			

  		}
  	}
  	$this->drop_mail();
  	
  }

  function search_mail()
  {
  	$user_first_name = $this->Session->read ('Auth.User.first_name');
  	$this->render(false);
  	$email = $this->Session->read ('Auth.User.email');
  	//$email = 'test1@aumlsolutions.com';
  	$this->loadModel('ClientSearch');
  	$search_criteria = $this->ClientSearch->find('all');
  	if(!empty($search_criteria))
  	{
  		foreach ($search_criteria as $key => $data)
  		{
  			$first_name = $data['ClientSearch']['first_name'];
  			$last_name = $data['ClientSearch']['last_name'];
  			$dob = $data['ClientSearch']['dob'];
  			$country = $data['ClientSearch']['country'];
  		
  			$result = $this->Client->find('all',array('conditions'=>array('first_name'=>$first_name,'last_name'=>$last_name,'country'=>$country,'dob'=>$dob)));
  			if(!empty($result))
  			{
  				$search_criteria[$key]['ClientSearch']['search_status'] = "true";
  			}
  			else
  			{
  				$search_criteria[$key]['ClientSearch']['search_status'] = "false";	
  			}

  		}
  		
  		$viewVars = array(
						'user_name'=>$user_first_name,
						'search_data' => $search_criteria,
				);
  	   $this->sendMail(array($email), 'client_search', $subject='Client Search Result', $viewVars );
  	
  	}
  	
  	
  }

  function drop_mail()
  {
  	 $this->loadModel('DeliveredEmail');
  	 $this->DeliveredEmail->bindModel(array(
            'belongsTo' => array(
                'User' => array('foreignKey' => 'search_by',
                                ),
                
                            )
                ),
            false
        );
  	$result = $this->DeliveredEmail->find('all',array('conditions'=>array('mail_sent'=>'false')));
  	if(!empty($result))
  	{
  	foreach ($result as $val)
  	{
  			$viewVars = array(
						'search_data' => $val,
				);
  	   $email_to = explode(',',$val['DeliveredEmail']['email_to']);
  	   $email_from = $val['DeliveredEmail']['email_from'];
  	   $email_cc = explode(',',$val['DeliveredEmail']['email_cc']);
  	   $email_bcc = explode(',',$val['DeliveredEmail']['email_bcc']);
  	   
  	   $this->sendMail($email_to, 'client_search', $subject='Client Search Result', $viewVars );
  	   $this->DeliveredEmail->Create();
  	   $this->DeliveredEmail->updateAll(array("mail_sent"=>true),array("DeliveredEmail.id"=>$val['DeliveredEmail']['id']));
  	}
	}
	else
	{
		//not send
	}
  }


  public function upload_client()
  {
  	$this->layout='internal';
  }


  public function update_profile()
  {
  	    $user_type = $this->Session->read ( 'Auth.User.type' );
		if (!in_array ($user_type, array ('SUPER_ADMIN','ADMIN'))) {
			return $this->redirect(array('controller'=>'users','action' => 'dashboard'));
		}
		$this->layout = 'internal';
  }


}
