<?php
class LogsController extends AppController {
	var $name = 'Logs';

	public function myactivity() {
		$this->layout='internal';
		$this->Paginator->settings = array(
				'conditions'=>array('Log.user_id'=>$this->Session->read('Auth.User.id')),
				'order' => array(
						'Activity.id' => 'DESC'
				),
		);
		$this->Log->recursive = 0;
		$this->set('activities', $this->Paginator->paginate());
	}


	public function index() {
		$this->layout='internal';
		$this->Paginator->settings = array(
				'order' => array(
						'Activity.id' => 'DESC'
				),
		);
		$this->Log->recursive = 0;
		$this->set('activities', $this->Paginator->paginate());
		$this->view = 'myactivity';
	}

}
?>

