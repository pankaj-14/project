<?php

App::uses('Component', 'Controller');
App::import('Vendor', 'JqueryFileUpload.UploadHandler', array('file' => 'UploadHandler.php'));
App::import('Vendor', 'getid3/getdata');

class UploadComponent extends Component {
	public $components = array('Auth');
    public function uploadFile($options = null,$type,$upload_dir,$upload_url) { 
    	
      $file =  new UploadHandler($options);
    	$file_lists = $file->post(false); 
    	$finfo = new finfo(FILEINFO_MIME_TYPE);
    	//$mimetype = $finfo->buffer(file_get_contents($file_lists['files']['0']->url));
    	$file_dir = $options['upload_dir'].$file_lists['files']['0']->name; 
    	//
    	$image_ext = explode(".",$file_lists['files']['0']->name);
      //$dest_dir = $upload_dir.'Client.'.$image_ext[1];
    	 if($type=='search')
      {
         $dest_dir = $upload_dir.Configure::read('search_file_name');
      }
       if($type=='update')
      {
         $dest_dir = $upload_dir.Configure::read('update_file_name');
      }
      else
      {
        $dest_dir = $upload_dir.Configure::read('client_file_name');
      }

      //
    	
    	
    	if($file_lists['files']['0']->size>0 && empty($file_lists['files']['0']->error)){
  	 		if(rename($file_dir, $dest_dir))
  	 		{
  	 			
  	 		}
  	 		
    	}
    	
    	if (file_exists($file_dir)) {
    		//unlink($file_dir);
    	}
    	unset($file_lists['files']['0']->url);
    	unset($file_lists['files']['0']->thumbnail_url);
    	unset($file_lists['files']['0']->delete_url);
    	unset($file_lists['files']['0']->name);
    	echo json_encode($file_lists);
        //return new UploadHandler($options);
    }

    public function deleteFile($options = null) {
        $file = new UploadHandler($options, false);
        return $file->delete();
    }
    
}

?>
