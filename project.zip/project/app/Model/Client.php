<?php
class Client extends AppModel {
	var $name = 'Client';

	function import($filename) {
 		$filename = $upload_url = Router::url('/', true). Configure::read ('client_file_path').$filename;
		$file = fopen($filename,"r");
		while(! feof($file))
		  {
		  		$row = fgetcsv($file);
		  		if(count($row)==10)
		  		{
		  			$this->create();
		  			$data['Client']['status']=$row[0];
		  			$data['Client']['first_name']=$row[1];
		  			$data['Client']['middle_name']=$row[2];
		  			$data['Client']['last_name']=$row[3];
		  			$data['Client']['dob']=$row[4];
		  			$data['Client']['address']=$row[5];
		  			$data['Client']['city']=$row[6];
		  			$data['Client']['state']=$row[7];
		  			$data['Client']['country']=$row[8];
		  			$data['Client']['mobile']=$row[9];
		  			$this->save($data);
		  		}

		  }

		fclose($file);

	}


	function update($filename) {
 		$filename = $upload_url = Router::url('/', true). Configure::read ('client_file_path').$filename;
		$file = fopen($filename,"r");
		while(! feof($file))
		  {
		  		$row = fgetcsv($file);
		  		echo count($row);
		  		if(count($row)==11)
		  		{
		  			$this->create();
		  			$data = $this->findById($row[0]);
		  			if(!empty($data))
		  			{
		  			$data['Client']['id']=$row[0];	
		  			}
		  			$data['Client']['status']=$row[1];
		  			$data['Client']['first_name']=$row[2];
		  			$data['Client']['middle_name']=$row[3];
		  			$data['Client']['last_name']=$row[4];
		  			$data['Client']['dob']=$row[5];
		  			$data['Client']['address']=$row[6];
		  			$data['Client']['city']=$row[7];
		  			$data['Client']['state']=$row[8];
		  			$data['Client']['country']=$row[9];
		  			$data['Client']['mobile']=$row[10];
		  			$this->save($data);
		  		}

		  }

		fclose($file);

	}

}

