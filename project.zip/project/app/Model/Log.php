<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 * @property Activity $Activity
 * @property Collection $Collection
 * @property Media $Media
 */
class Log extends AppModel {

}
