<?php
class ClientSearch extends AppModel {
	var $name = 'ClientSearch';

	function import($filename,$user_by) {
	$filename = $upload_url = Router::url('/', true). Configure::read ('client_file_path').$filename;
		
		$file = fopen($filename,"r");

		while(! feof($file))
		  {
		  		$row = fgetcsv($file);
		  		if(count($row)==4)
		  		{
		  			$this->create();
		  			$data['ClientSearch']['first_name']=$row[0];
		  			$data['ClientSearch']['last_name']=$row[1];
		  			$data['ClientSearch']['dob']=$row[2];
		  			$data['ClientSearch']['country']=$row[3];
		  			$data['ClientSearch']['search_by']=$user_by;
		  			$this->save($data);
		  		}

		  }

		fclose($file);
	}

}

