<?php
class ClientSearchBackup extends AppModel {
	var $name = 'ClientSearchBackup';

}

